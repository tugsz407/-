ХУДАЛЧИЙГ ОЛ! · Гэр бүлийн тоглоом

Энэ хавтас нь Android дээр ажиллуулахад бэлэн React + Vite + Capacitor эх төсөл.

APK гаргахын тулд:
1. Компьютерт Node.js LTS болон Android Studio суулгана.
2. Энэ хавтсыг задлаад Terminal / Command Prompt нээнэ.
3. Дараах командыг дарааллаар ажиллуулна:

   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android

4. Android Studio нээгдсэний дараа Gradle sync дуусахыг хүлээнэ.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) сонгоно.
6. APK нь android/app/build/outputs/apk/debug/app-debug.apk дотор үүснэ.

Түр турших:
   npm run dev
Компьютер болон утас нэг Wi-Fi-д байхад Vite-ийн гаргасан Network URL-ийг Android Chrome дээр нээж болно.

Тайлбар:
- Офлайн, нэг утсаар тоглох хувилбар.
- Дор хаяж 3 тоглогч шаардлагатай.
- APK-г гаргахын тулд Android Studio бүхий компьютер хэрэгтэй.
