import React, { useState } from 'react';
import { UserPlus, Trash2, Play, EyeOff, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';

const WORD_BANK = [
  { word: "Морин хуур", category: "Монголын өв соёл" },
  { word: "Ээзгий", category: "Монгол хоол хүнс" },
  { word: "Хархорин", category: "Түүхэн газар зүй" },
  { word: "Шагай", category: "Уламжлалт тоглоом" },
  { word: "Арслан", category: "Амьтад" },
  { word: "Гэр", category: "Өдөр тутмын эд зүйлс" },
  { word: "Айраг", category: "Монгол хоол хүнс" },
  { word: "Наадам", category: "Монголын өв соёл" },
  { word: "Ирвэс", category: "Амьтад" },
  { word: "Бөртэ", category: "Түүхэн хүмүүс" }
];

export default function App() {
  const [players, setPlayers] = useState([]);
  const [newPlayerName, setNewPlayerName] = useState('');
  const [gameState, setGameState] = useState('setup');
  const [currentPlayerIdx, setCurrentPlayerIdx] = useState(0);
  const [showCard, setShowCard] = useState(false);
  const [secretWord, setSecretWord] = useState('');
  const [imposterCategory, setImposterCategory] = useState('');
  const [imposterIndex, setImposterIndex] = useState(null);
  const [votes, setVotes] = useState({});
  const [votedCount, setVotedCount] = useState(0);
  const [votingPlayerIdx, setVotingPlayerIdx] = useState(0);
  const [votedSuccess, setVotedSuccess] = useState(false);

  const handleAddPlayer = (e) => {
    e.preventDefault();
    const name = newPlayerName.trim();
    if (!name || players.some(p => p.name.toLowerCase() === name.toLowerCase())) return;
    setPlayers([...players, { id: `${Date.now()}-${Math.random()}`, name }]);
    setNewPlayerName('');
  };

  const handleRemovePlayer = (id) => setPlayers(players.filter(p => p.id !== id));

  const startGame = () => {
    if (players.length < 3) return;
    const item = WORD_BANK[Math.floor(Math.random() * WORD_BANK.length)];
    setSecretWord(item.word);
    setImposterCategory(item.category);
    setImposterIndex(Math.floor(Math.random() * players.length));
    setCurrentPlayerIdx(0);
    setShowCard(false);
    setGameState('roleview');
    setVotes({});
    setVotedCount(0);
    setVotingPlayerIdx(0);
    setVotedSuccess(false);
  };

  const handleNextRoleView = () => {
    setShowCard(false);
    if (currentPlayerIdx + 1 < players.length) setCurrentPlayerIdx(currentPlayerIdx + 1);
    else setGameState('discussion');
  };

  const handleCastVote = (targetIdx) => {
    const updated = { ...votes };
    if (targetIdx !== null) updated[targetIdx] = (updated[targetIdx] || 0) + 1;
    setVotes(updated);
    setVotedCount(votedCount + 1);
    setVotedSuccess(true);
    window.setTimeout(() => {
      setVotedSuccess(false);
      if (votingPlayerIdx + 1 < players.length) setVotingPlayerIdx(votingPlayerIdx + 1);
      else setGameState('result');
    }, 800);
  };

  const resetGame = () => {
    setGameState('setup');
    setShowCard(false);
    setVotes({});
    setVotedCount(0);
    setVotingPlayerIdx(0);
  };

  const getMostVotedIndex = () => {
    let max = 0, winner = null, tied = false;
    Object.entries(votes).forEach(([idx, count]) => {
      if (count > max) { max = count; winner = Number(idx); tied = false; }
      else if (count === max && count > 0) tied = true;
    });
    return tied ? null : winner;
  };

  const mostVotedIdx = getMostVotedIndex();
  const imposterCaught = mostVotedIdx === imposterIndex;

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-4">
      <section className="w-full max-w-md bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 p-5 sm:p-6">
        <header className="text-center mb-7">
          <span className="inline-block bg-indigo-500/15 text-indigo-300 px-3 py-1 rounded-full text-xs font-semibold tracking-wider mb-2">ГЭР БҮЛИЙН ТОГЛООМ</span>
          <h1 className="text-3xl font-black tracking-tight text-white">ХУДАЛЧИЙГ ОЛ!</h1>
          <p className="text-slate-400 text-xs mt-1">Нэг нь нууц үгийг мэдэхгүй...</p>
        </header>

        {gameState === 'setup' && <div className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">Тоглогчдын нэр</label>
            <form onSubmit={handleAddPlayer} className="flex gap-2 mb-3">
              <input value={newPlayerName} onChange={e => setNewPlayerName(e.target.value)} placeholder="Нэр бичих..." maxLength={22}
                className="min-w-0 flex-1 px-4 py-3 rounded-xl border border-slate-700 bg-slate-800 text-white placeholder:text-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 rounded-xl font-semibold text-sm flex items-center gap-1"><UserPlus size={17}/> Нэмэх</button>
            </form>
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {players.length === 0 ? <p className="text-xs text-slate-500 text-center py-5">Одоогоор тоглогч алга. Дор хаяж 3 хүн нэмээрэй.</p> :
                players.map((p, i) => <div key={p.id} className="flex justify-between items-center bg-slate-800 border border-slate-700 px-3 py-3 rounded-xl">
                  <span className="text-sm font-medium">{i + 1}. {p.name}</span>
                  <button aria-label={`${p.name} устгах`} onClick={() => handleRemovePlayer(p.id)} className="text-slate-400 hover:text-red-400 p-1"><Trash2 size={17}/></button>
                </div>)}
            </div>
          </div>
          <button onClick={startGame} disabled={players.length < 3} className="w-full py-4 rounded-xl font-bold text-white flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-400 shadow-lg"><Play size={19} fill="currentColor"/> Тоглоом эхлүүлэх ({players.length}/3+)</button>
        </div>}

        {gameState === 'roleview' && <div className="text-center space-y-5 py-3">
          <div className="bg-indigo-500/10 border border-indigo-400/20 p-4 rounded-2xl">
            <p className="text-sm text-indigo-300 mb-1">Утсаа дараах тоглогчид өгнө үү</p>
            <h2 className="text-2xl font-bold text-white">{players[currentPlayerIdx]?.name}</h2>
          </div>
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6 min-h-44 flex flex-col justify-center items-center">
            {!showCard ? <div className="space-y-4">
              <EyeOff size={38} className="text-slate-400 mx-auto"/>
              <p className="text-xs text-slate-400">Бусад тоглогчдод харуулахгүйгээр картаа үзээрэй.</p>
              <button onClick={() => setShowCard(true)} className="bg-white text-slate-900 px-6 py-3 rounded-xl text-sm font-bold">Карт харах</button>
            </div> : <div className="space-y-4 w-full">
              {currentPlayerIdx === imposterIndex ? <><span className="inline-block bg-pink-500/15 text-pink-300 text-xs px-3 py-1 rounded-full font-bold">IMPOSTER</span><h3 className="text-lg font-bold">Сэдэв: {imposterCategory}</h3></> :
                <><span className="inline-block bg-emerald-500/15 text-emerald-300 text-xs px-3 py-1 rounded-full font-bold">ЖИНХЭНЭ ТОГЛОГЧ</span><h3 className="text-3xl font-black text-indigo-300">{secretWord}</h3></>}
              <button onClick={handleNextRoleView} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-3 rounded-xl text-sm font-bold">Ойлголоо / Хаах</button>
            </div>}
          </div>
        </div>}

        {gameState === 'discussion' && <div className="text-center space-y-6 py-5">
          <Sparkles size={40} className="text-amber-400 mx-auto"/>
          <h2 className="text-xl font-bold">Тайлбарлах ба хэлэлцэх үе</h2>
          <p className="text-sm text-slate-400">Тоглогч бүр ээлжээр өөрийн үг эсвэл сэдэвтэй холбоотой 1-2 үг хэлнэ.</p>
          <button onClick={() => setGameState('voting')} className="w-full bg-pink-600 hover:bg-pink-500 text-white font-bold py-4 rounded-xl">Санал хураалт руу шилжих</button>
        </div>}

        {gameState === 'voting' && <div className="space-y-5">
          <div className="bg-slate-800 border border-slate-700 p-4 rounded-xl text-center">
            <p className="text-xs text-slate-400">Нууц санал хураалт ({votedCount}/{players.length})</p>
            <h3 className="text-lg font-bold mt-1">Санал өгч буй: <span className="text-indigo-300">{players[votingPlayerIdx]?.name}</span></h3>
          </div>
          {votedSuccess ? <div className="py-8 text-center text-emerald-300 font-bold flex items-center justify-center gap-2"><CheckCircle2 size={22}/> Санал бүртгэгдлээ</div> :
            <div className="space-y-2">
              <p className="text-xs text-slate-400 mb-2">Хэнийг Imposter гэж сэжиглэж байна вэ?</p>
              {players.map((p, i) => i !== votingPlayerIdx && <button key={p.id} onClick={() => handleCastVote(i)} className="w-full py-3 px-4 bg-slate-800 border border-slate-700 hover:border-indigo-400 rounded-xl text-left font-medium flex justify-between"><span>{p.name}</span><span className="text-xs text-slate-400">Сонгох</span></button>)}
              <button onClick={() => handleCastVote(null)} className="w-full py-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-400 text-sm">Алгасах</button>
            </div>}
        </div>}

        {gameState === 'result' && <div className="text-center space-y-5 py-4">
          <h2 className="text-2xl font-black">Тоглоомын үр дүн</h2>
          <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 space-y-2 text-sm">
            <p className="text-slate-400">Нууц үг: <b className="text-white">{secretWord}</b></p>
            <p className="text-slate-400">Imposter: <b className="text-pink-300">{players[imposterIndex]?.name}</b></p>
            <p className="text-slate-400">Хамгийн олон санал: <b className="text-white">{mostVotedIdx === null ? 'Тэнцсэн эсвэл санал аваагүй' : players[mostVotedIdx]?.name}</b></p>
          </div>
          <div className={`p-4 rounded-xl border ${imposterCaught ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200' : 'bg-pink-500/10 border-pink-500/30 text-pink-200'}`}>
            <h3 className="font-bold text-lg mb-1">{imposterCaught ? 'Жирийн тоглогчид яллаа!' : 'Imposter яллаа!'}</h3>
            <p className="text-xs">{imposterCaught ? 'Олонхын саналаар Imposter-ийг олж илрүүллээ.' : 'Imposter баригдсангүй.'}</p>
          </div>
          <button onClick={resetGame} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2"><RotateCcw size={18}/> Дахин тоглох</button>
        </div>}
        <footer className="text-center text-[10px] text-slate-600 mt-7">OFFLINE PARTY GAME · НЭГ УТСААР ТОГЛОНО</footer>
      </section>
    </main>
  );
}
